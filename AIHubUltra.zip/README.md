# AI Hub Ultra

Schlankes Windows-Tool mit Direktlinks zu über 69 KI-Anwendungen - übersichtlich sortiert, mit Favoriten, ganz ohne Installation.

## Funktionen

- **69+ KI-Tools** in 4 Kategorien: Text & Chat, Bild & Video, Audio & Musik, Code & Dev
- **Favoriten**: bis zu 6 Lieblings-Tools per Sternklick anheften, dauerhaft gespeichert
- **Rechtsklick-Menü**: Link kopieren oder im Standardbrowser öffnen
- **Dark/Light Mode** per Klick umschaltbar
- **Deutsch/Englisch**: erkennt automatisch die Windows-Systemsprache, manuell umschaltbar
- Responsive Fenstergröße, eigenes App-Icon, keine Installation nötig

## Haftungsausschluss

Dieses Tool wird kostenlos zur Verfügung gestellt und darf auf eigene Gefahr genutzt werden. Es wird keine Haftung für die Funktionsfähigkeit des Tools sowie für Inhalte, Verfügbarkeit oder Datenschutz der verlinkten externen Webseiten übernommen. Alle verlinkten Marken- und Produktnamen gehören ihren jeweiligen Eigentümern.

## Autor

© Björn Scherf - 2026
